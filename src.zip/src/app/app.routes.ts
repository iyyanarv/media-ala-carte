import { Routes } from '@angular/router';
import { LoginComponent } from './features/login/login.component';

export const routes: Routes = [
    { path: '', redirectTo: '/platform', pathMatch: 'full' },
    { path: 'platform', loadComponent: () => import('./features/platform/platform.component').then(m => m.PlatformComponent) },
    { path: 'features', loadComponent: () => import('./features/feature/feature.component').then(m => m.FeatureComponent) },
    { path: 'benefits', loadComponent: () => import('./features/benefits/benefits.component').then(m => m.BenefitsComponent) },
    { path: 'request-demo', loadComponent: () => import('./features/req-demo/req-demo.component').then(m => m.ReqDemoComponent) },
    { path: 'contact', loadComponent: () => import('./features/contact-us/contact-us.component').then(m => m.ContactUsComponent) },
    { path: 'about', loadComponent: () => import('./features/about-us/about-us.component').then(m => m.AboutUsComponent) },
    { path: 'login', component: LoginComponent }
];
