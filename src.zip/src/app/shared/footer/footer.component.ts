import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  imports: [CommonModule],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {

  constructor(public router: Router) {}

    footerLinks1 = [
    { label: 'The Platform', href: '#' },
    { label: 'Features', href: '#' },
    { label: 'Benefits', href: '#' },
    { label: 'Request a Demo', href: '#' },
    { label: 'Terms of Service', href: '#' },
  ];
 
  footerLinks2 = [
    { label: 'Contact Us', href: '#' },
    { label: 'About Us', href: '#' },
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms of Service', href: '#' },
  ];

}
