import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  imports: [],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {

  constructor(public router: Router) { };

  toggleMenu() {
    const links = document.querySelector('.nav-links') as HTMLElement | null;
    if (links) {
      links.style.display = links.style.display === 'flex' ? 'none' : 'flex';
      links.style.flexDirection = 'column';
      links.style.position = 'absolute';
      links.style.top = '70px';
      links.style.left = '0'; links.style.right = '0';
      links.style.background = 'rgba(10,10,15,0.98)';
      links.style.padding = '20px 6vw';
    }
  }

}
