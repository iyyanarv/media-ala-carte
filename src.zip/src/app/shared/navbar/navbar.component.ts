import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  imports: [],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {

  constructor(public router: Router) { };

menuOpen = false;

toggleMenu() {
  this.menuOpen = !this.menuOpen;
  document.body.classList.toggle('menu-open', this.menuOpen);
}

navigate(path: string) {
  this.router.navigate([path]);
  this.menuOpen = false;
  document.body.classList.remove('menu-open');
}

}
