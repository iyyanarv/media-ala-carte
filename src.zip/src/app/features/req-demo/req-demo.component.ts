import { Component } from '@angular/core';
import { NavbarComponent } from '../../shared/navbar/navbar.component';
import { FooterComponent } from '../../shared/footer/footer.component';
import { FormGroup, FormBuilder, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';

@Component({
  selector: 'app-req-demo',
  imports: [NavbarComponent, FooterComponent, ReactiveFormsModule, FormsModule],
  templateUrl: './req-demo.component.html',
  styleUrl: './req-demo.component.css'
})
export class ReqDemoComponent {

  form: FormGroup;
  submitted = false;
  success = false;

  benefits = [
    '30-minute personalised walkthrough',
    'Live demo tailored to your use case',
    'Q&A with a media expert',
    'Custom pricing & package overview',
    'No spam — just value',
  ];

  constructor(private fb: FormBuilder) {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.form = this.fb.group({
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      email: ['', [Validators.required, Validators.email]],
      company: ['', [Validators.required, Validators.minLength(2)]],
      role: ['', Validators.required],
      goals: ['', [Validators.required, Validators.minLength(10)]]
    });
  };

  f(field: string) { return this.form.get(field)!; }

  isInvalid(field: string): boolean {
    return this.f(field).invalid && (this.f(field).touched || this.submitted);
  }
  onSubmit() {
    this.submitted = true;
    if (this.form.invalid) return;
    this.success = true;
    this.form.reset();
    this.submitted = false;
  }

}
