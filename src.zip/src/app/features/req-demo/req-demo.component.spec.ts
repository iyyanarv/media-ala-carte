import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReqDemoComponent } from './req-demo.component';

describe('ReqDemoComponent', () => {
  let component: ReqDemoComponent;
  let fixture: ComponentFixture<ReqDemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReqDemoComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReqDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
