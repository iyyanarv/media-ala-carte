import { Component } from '@angular/core';
import { NavbarComponent } from '../../shared/navbar/navbar.component';
import { FooterComponent } from '../../shared/footer/footer.component';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';

@Component({
  selector: 'app-contact-us',
  imports: [NavbarComponent, FooterComponent, ReactiveFormsModule, FormsModule],
  templateUrl: './contact-us.component.html',
  styleUrl: './contact-us.component.css'
})
export class ContactUsComponent {

  form: FormGroup;
submitted = false;
success = false;

  constructor(private fb: FormBuilder) {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    this.form = this.fb.group({
      name:    ['', [Validators.required, Validators.minLength(2)]],
      email:   ['', [Validators.required, Validators.email]],
      phone:   ['', [Validators.pattern(/^\+?[0-9\s\-]{7,15}$/)]],
      subject: ['', Validators.required],
      message: ['', [Validators.required, Validators.minLength(10)]]
    });
  };


  // helper for quick template access
  f(field: string) { return this.form.get(field)!; }

  isInvalid(field: string): boolean {
    return this.f(field).invalid && (this.f(field).touched || this.submitted);
  }

onSubmit() {
  this.submitted = true;
  if (this.form.invalid) return;
  this.success = true;
  this.form.reset();
  this.submitted = false;
}

}
