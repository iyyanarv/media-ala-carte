import { CommonModule, DecimalPipe } from '@angular/common';
import { Component } from '@angular/core';
import { NavbarComponent } from '../../shared/navbar/navbar.component';
import { FooterComponent } from '../../shared/footer/footer.component';

interface Feature {
  id: number; icon: string; title: string; tagline: string; cat: string;
  desc: string; bullets?: string[]; steps?: { num: string; label: string; desc: string }[];
}

@Component({
  selector: 'app-feature',
  imports: [CommonModule, NavbarComponent, FooterComponent],
  templateUrl: './feature.component.html',
  styleUrl: './feature.component.css'
})
export class FeatureComponent {

  activeId = 1;

  cats: Record<string, { label: string; color: string }> = {
    automation: { label: 'Automation', color: '#E8193C' },
    planning: { label: 'Planning', color: '#7C4DFF' },
    insights: { label: 'Insights', color: '#00B4D8' },
    management: { label: 'Management', color: '#06D6A0' },
    support: { label: 'Support', color: '#FFB703' },
  };

  features: Feature[] = [
    {
      id: 1, icon: '⚡', title: 'Programmatic', cat: 'automation',
      tagline: 'Leading the Way to Effective & Efficient Media Buying',
      desc: 'Media Alacarte is a programmatic media buying and planning agency that utilizes a custom platform software delivering integrated omnichannel workflow that helps perform more effective and efficient media buying and planning.',
      bullets: ['Automated technology for media buying', 'Data insights & algorithms at every step', 'Right user, right time, right price', 'Omnichannel workflow in one platform', 'No minimum spend or contract required']
    },
    {
      id: 2, icon: '📊', title: 'Media Buying', cat: 'planning',
      tagline: 'Media Buying & Planning Is Our Game',
      desc: 'Our Buying and Planning Team consists of seasoned buyers and planners throughout the Saudi and UAE Market. With combined decades of experience, our team works hard for the best interests of you and your clients.',
      steps: [
        { num: '01', label: 'Contact Us', desc: 'Let us know basic information about your media project.' },
        { num: '02', label: 'Consult With Us', desc: "After receiving your form, we'll reach out to discuss details and confirm." },
        { num: '03', label: 'Planner/Buyer Match', desc: "We'll match you with a planner/buyer based on your project needs." },
        { num: '04', label: 'Media Buying Begins', desc: 'Our planner/buyer gets to work placing the buy in your account.' },
      ]
    },
    {
      id: 3, icon: '🔍', title: 'Digital Insights', cat: 'insights',
      tagline: 'Graph & Compare Results Against Your Analytics Data',
      desc: 'Our tool gives you access to an automated platform that addresses programmatic buying with extensive retargeting capability, location targeting, custom audience segmenting, and a host of other digital marketing needs.',
      bullets: ['Impressions tracking', 'CPM analysis', 'Cost reporting', 'Reach measurement', 'Frequency monitoring', 'Facebook Ads integration', 'Google Ads integration']
    },
    {
      id: 4, icon: '🔗', title: 'Online Media Integration', cat: 'insights',
      tagline: 'Facebook Ads & Google Ads — Integration',
      desc: 'At Media Alacarte, we understand that aggregation of your data across multiple platforms is important. Connect your media plans directly to your ad sets for seamless tracking and reporting.',
      bullets: ['Plan media buys using digital worksheets', 'Connect your plan to Facebook Ads ad sets', 'Choose tracking frequency (hourly, daily)', 'Graph spending against Google Analytics traffic', 'Unified reporting across all platforms']
    },
    {
      id: 5, icon: '📋', title: 'Downloadable Worksheets', cat: 'planning',
      tagline: 'Customizable Worksheets for Every Media',
      desc: "Media Alacarte makes it easy to create orders for every media type in your client's campaign. Our worksheet types span all major media channels with full customization options.",
      bullets: ['Broadcast television worksheets', 'Cable & radio templates', 'Outdoor & print planning', 'Digital media worksheets', 'Custom filters per worksheet', 'One-click report generation']
    },
    {
      id: 6, icon: '🏠', title: 'Dashboard', cat: 'management',
      tagline: 'Easily Access Your Campaigns and Worksheets',
      desc: 'The dashboard is designed to be simple and user-friendly. Users can easily navigate their profile activities, scan all projects at a glance, and access everything they need from one central hub.',
      bullets: ['Unified overview of all campaigns', 'Quick-link navigation to any project', 'Activity feed and recent updates', 'Performance snapshot at a glance', 'User-friendly, minimal learning curve']
    },
    {
      id: 7, icon: '🎯', title: 'Campaigns', cat: 'planning',
      tagline: 'Plan Your Campaign in a Snap',
      desc: "Media Alacarte's software helps you create a new campaign instantly. Think of it as the umbrella under which all your media plans live — add unlimited plans in unlimited markets.",
      bullets: ['Unlimited plans per campaign', 'Custom timeframe calendar', 'Booked / Live / Completed categories', 'Client-specific organization', 'Easy campaign duplication & reuse']
    },
    {
      id: 8, icon: '💳', title: 'Billing Features', cat: 'management',
      tagline: 'Upload Invoices & Reconcile Buys in Minutes',
      desc: 'We understand that time equals money. Populating individual program lines can be time-consuming. Import avails and full proposals directly into your worksheet to save time and money.',
      bullets: ['Upload digital invoices instantly', 'Manual line-item input support', 'Reconcile against worksheets', 'Import avails from vendors', 'Full proposal import support']
    },
    {
      id: 9, icon: '👥', title: 'Team Settings', cat: 'management',
      tagline: 'Assign Account Users On the Go',
      desc: 'Admins have the ability to set up teams inside their accounts. These teams can be single users or combinations of users. Users can be made active or inactive at any time.',
      bullets: ['Admin team creation & management', 'Granular user permissions per client', 'Active / Inactive user toggle', 'Restricted access for privacy', 'Multi-user collaboration support']
    },
    {
      id: 10, icon: '📈', title: 'Reporting', cat: 'insights',
      tagline: 'Customized Reporting at Every Level',
      desc: 'Customized reporting at the worksheet, campaign, vendor, or client level — and so much more! Get the exact data you need presented exactly the way you want it.',
      bullets: ['Worksheet-level reports', 'Campaign-level summaries', 'Vendor performance reports', 'Client-level dashboards', 'Exportable data & downloads']
    },
    {
      id: 11, icon: '🔎', title: 'Campaign Filtration', cat: 'management',
      tagline: 'Choose Filters That Fit Your Needs',
      desc: 'We understand that all planners and buyers look at a buy differently. Our data filters and customization options let each user work in the format optimal for their flow.',
      bullets: ['Filter by single daypart or vendor', 'Show only lines with spots', 'Hide or freeze any column', 'Personalized view per user', 'Team-specific filter presets']
    },
    {
      id: 12, icon: '🛠️', title: 'Custom Features', cat: 'support',
      tagline: 'Submit Requests for Your Ideal Experience',
      desc: 'Our system is intended to evolve over time as a result of feedback and usability requests from our users. Every feature we have was born from a client conversation.',
      bullets: ['Submit feature requests anytime', 'Direct line to development team', 'Priority queue based on usage', 'Regular feature release cycle', 'Collaborative product roadmap']
    },
    {
      id: 13, icon: '💬', title: 'Customer Support', cat: 'support',
      tagline: 'Highly Responsive Support Team',
      desc: "With support staff always at reach, our team is ready and waiting to answer any questions 7 days a week. Our goal is to make you feel like you are the ONLY client in the world!",
      bullets: ['7-day-a-week availability', 'Individual dedicated care', 'Feature request submission', 'Platform onboarding support', 'Response within hours, not days']
    },
  ];

  constructor() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  get active(): Feature { return this.features.find(f => f.id === this.activeId)!; }
  prevF(): Feature | null { return this.features.find(f => f.id === this.activeId - 1) ?? null; }
  nextF(): Feature | null { return this.features.find(f => f.id === this.activeId + 1) ?? null; }
  select(id: number): void { this.activeId = id; }
  pad(n: number): string { return String(n).padStart(2, '0'); }
}
