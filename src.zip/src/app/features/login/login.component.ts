import { CommonModule } from '@angular/common';
import { FormControl, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  email = new FormControl('', [Validators.required, Validators.email]);
  submitted = false;
 
  // decorative background tiles
  tiles = [
    { width: '180px', height: '120px', top: '8%',  left: '2%' },
    { width: '180px', height: '120px', top: '8%',  left: '21%' },
    { width: '180px', height: '120px', top: '32%', left: '2%' },
    { width: '180px', height: '120px', top: '32%', left: '21%' },
    { width: '180px', height: '120px', top: '56%', left: '2%' },
    { width: '180px', height: '120px', top: '8%',  right: '2%' },
    { width: '180px', height: '120px', top: '8%',  right: '21%' },
    { width: '180px', height: '120px', top: '32%', right: '2%' },
    { width: '180px', height: '120px', top: '32%', right: '21%' },
    { width: '180px', height: '120px', top: '56%', right: '2%' },
  ];
 
  constructor(public router: Router) { }

  onSubmit() {
    if (this.email.invalid) return;
    this.submitted = true;
  }

}
