import { Component } from '@angular/core';
import { NavbarComponent } from '../../shared/navbar/navbar.component';
import { FooterComponent } from '../../shared/footer/footer.component';

@Component({
  selector: 'app-platform',
  imports: [NavbarComponent, FooterComponent],
  templateUrl: './platform.component.html',
  styleUrl: './platform.component.css'
})
export class PlatformComponent {

  constructor() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

}
