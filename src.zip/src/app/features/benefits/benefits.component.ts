import { Component } from '@angular/core';
import { FooterComponent } from '../../shared/footer/footer.component';
import { NavbarComponent } from '../../shared/navbar/navbar.component';

@Component({
  selector: 'app-benefits',
  imports: [FooterComponent, NavbarComponent],
  templateUrl: './benefits.component.html',
  styleUrl: './benefits.component.css'
})
export class BenefitsComponent {

  constructor() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

}
